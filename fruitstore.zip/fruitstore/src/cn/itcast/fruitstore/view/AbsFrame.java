package cn.itcast.fruitstore.view;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import cn.itcast.fruitstore.tools.GUITools;

public abstract class AbsFrame extends JFrame {
	private JLabel titleLabel = new JLabel(new ImageIcon("D:\\java\\java������\\fruitstore\\myImage\\21.jpg"));
	private JButton btn = new JButton("����ϵͳ");
    
	public AbsFrame() {
		this.init();
		this.addComponent();
		this.addListener();
	}
	private void init() {
		this.setTitle("��ӭ��������ϵͳ��");
		this.setSize(600, 400);
		GUITools.center(this);
		GUITools.setTitleImage(this, "title.png");
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	private void addComponent() {
		this.add(this.titleLabel, BorderLayout.NORTH);
		JPanel btnpanel = new JPanel();
		btnpanel.setLayout(null);
		this.add(btnpanel);
		btn.setBounds(240, 8, 120, 50);
		btnpanel.add(btn);
	}
	private void addListener() {
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showAdminDialog(); 
			}
		});
	}
	public abstract void showAdminDialog(); 
}

