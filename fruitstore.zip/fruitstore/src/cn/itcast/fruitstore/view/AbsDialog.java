package cn.itcast.fruitstore.view;

import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import cn.itcast.fruitstore.tools.GUITools;

public abstract class AbsDialog extends JDialog{
private JLabel tableLabel = new JLabel("������Ϣ");
private JScrollPane tablePane =new JScrollPane();//�����ӿ�
protected JTable table =new JTable();
private JLabel numberLabel =new JLabel("����");
private JLabel nameLabel =new JLabel("�Ա�");
private JLabel priceLabel =new JLabel("���ߣ��ף�");
private JLabel unitLabel =new JLabel("���أ�kg��");
protected JTextField addNumberText =new JTextField(6);//���ӱ���ı���
protected JTextField addNameText =new JTextField(6);
protected JTextField addPriceText =new JTextField(6);
protected JTextField addUnitText =new JTextField(6);
private JButton addBtn =new JButton("�Ǽ���Ϣ");
protected JTextField updateNumberText =new JTextField(6);//�޸��ı���
protected JTextField updateNameText =new JTextField(6);
protected JTextField updatePriceText =new JTextField(6);
protected JTextField updateUnitText =new JTextField(6);
protected JButton updateBtn =new JButton("�޸���Ϣ");//�޸İ�ť
protected JTextField delNumberText =new JTextField(6);//���ӱ���ı�
private JButton delBtn =new JButton("ɾ����Ϣ");//ɾ����ť
public AbsDialog(){
	this(null,true);
}
public AbsDialog(Frame owner, boolean modal) {
	super(owner,modal);
	this.init();
	this.addComponent();
	this.addListener();
}
private void init() {
	this.setTitle("ѧ��������Ϣ");
	this.setSize(600,400);
	GUITools.center(this);
	this.setResizable(false);	
}
private void addComponent() {
	this.setLayout(null);
	tableLabel.setBounds(265,20,70,25);
	this.add(tableLabel);
	table.getTableHeader().setReorderingAllowed(false);
	table.getTableHeader().setResizingAllowed(false);
	table.setEnabled(false);
	tablePane.setBounds(50,50,500,200);
	tablePane.setViewportView(table);//�ӿ�װ�����
	this.add(tablePane);
	numberLabel.setBounds(50,250,70,25);
	nameLabel.setBounds(150, 250, 70, 25);
	priceLabel.setBounds(250, 250, 70, 25);
	unitLabel.setBounds(350,250,70,25);
	this.add(numberLabel);
	this.add(nameLabel);
	this.add(priceLabel);
	this.add(unitLabel);
	addNumberText.setBounds(50,280,80,25);
	addNameText.setBounds(150,280,80,25);
	addPriceText.setBounds(250,280,80,25);
	addUnitText.setBounds(350,280,80,25);
	this.add(addNumberText);
	this.add(addNameText);
	this.add(addPriceText);
	this.add(addUnitText);
	addBtn.setBounds(460,280,90,25);
	this.add(addBtn);
	updateNumberText.setBounds(50,310,80,25);
	updateNameText.setBounds(150,310,80,25);
	updatePriceText.setBounds(250,310,80,25);
	updateUnitText.setBounds(350,310,80,25);
	this.add(updateNumberText);
	this.add(updateNameText);
	this.add(updatePriceText);
	this.add(updateUnitText);
	updateBtn.setBounds(460, 310, 90, 25);
	this.add(updateBtn);
	delNumberText.setBounds(50,340,80,25);
	this.add(delNumberText);
	delBtn.setBounds(460, 340, 90, 25);
	this.add(delBtn);
}
private void addListener() {
	//���Ӱ�ť����
	addBtn.addActionListener(new ActionListener(){
		
		@Override
		public void actionPerformed(ActionEvent e) {
			addFruitItem();			
		}		
	});
	//�޸İ�ť����
	updateBtn.addActionListener(new ActionListener(){
		
		@Override
		public void actionPerformed(ActionEvent e) {
			updateFruitItem();	
		}		
	});
	delBtn.addActionListener(new ActionListener(){
		
		@Override
		public void actionPerformed(ActionEvent e) {
			delFruitItem();		
		}		
	});
}
public abstract void queryFruitItem();
public abstract void addFruitItem();
public abstract void updateFruitItem();
public abstract void delFruitItem();
}
