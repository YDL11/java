package cn.itcast.fruitstore.view;

public class AbsFrameTest extends AbsFrame{
	public static void main(String[] args) {
	new AbsFrameTest().setVisible(true);
	}

	@Override
	public void showAdminDialog() {
		System.out.println("�����������");
		
	}
}
