package cn.itcast.fruitstore.ctl;

import java.awt.*;
import java.util.ArrayList;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import cn.itcast.fruitstore.domain.*;
import cn.itcast.fruitstore.service.*;
import cn.itcast.fruitstore.view.*;

public class AdminDialogCtl extends AbsDialog{

	private AdminService adminService =new AdminService();
	public AdminDialogCtl(){
		super();
	}
	public AdminDialogCtl(Frame owner,boolean modal){
		super(owner,modal);
		//��������ʱչʾ����
		queryFruitItem();
	}
	@Override
	public void queryFruitItem() {
		String []thead={"����","�Ա�","���ߣ��ף�","���أ�kg��"};
		ArrayList<FruiteItem>dataList=adminService.queryFruiteItem();
		String [][] tbody=list2Array(dataList);
		TableModel dataModel=new DefaultTableModel(tbody,thead);
		table.setModel(dataModel);
	}
     //��������תΪ��ά���鷽��
	public String[][] list2Array(ArrayList<FruiteItem> List) {
		String[][] tbody=new String[List.size()][4];
		for(int i=0;i<List.size();i++){
			FruiteItem frt=List.get(i);
			tbody[i][0]=frt.getNumber();
			tbody[i][1]=frt.getName();
			tbody[i][2]=frt.getjiage()+"";
			tbody[i][3]=frt.getNuit();
		}
		return tbody;
	}
	@Override
	public void addFruitItem() {
		String addNumber=addNumberText.getText();
		String addName=addNameText.getText();
		String addPrice=addPriceText.getText();
		String addUnit=addUnitText.getText();
		//����adminService�����ӷ���
		boolean addSuccess=adminService.addFruiteItem(addNumber, addName, 
				addPrice, addUnit);
		if(addSuccess){
			queryFruitItem();//����ɹ������Ӻ�ˢ�±���
		}else{
			JOptionPane.showMessageDialog(this, "���ݴ���,��������!");
		}
	}

	@Override
	public void updateFruitItem() {
		String updateNumber=updateNumberText.getText();
		String updateName=updateNameText.getText();
		String updatePrice=updatePriceText.getText();
		String updateUnit=updateUnitText.getText();
		boolean updateSuccess=adminService.updateFruiteItem(updateNumber, updateName,
				updatePrice, updateUnit);
		if(updateSuccess){
			queryFruitItem();
		}else{
			JOptionPane.showMessageDialog(this, "���ݴ���,��������!");
		}
	}

	@Override
	public void delFruitItem() {
		String delNumber=delNumberText.getText();
		boolean delSuccess=adminService.deleFruiteItem(delNumber);
		if(delSuccess){
			queryFruitItem();
		}else{
			JOptionPane.showMessageDialog(this, "���ݴ���,��������!");
		}
	}

}
