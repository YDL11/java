package cn.itcast.fruitstore.ctl;

import cn.itcast.fruitstore.view.AbsFrameTest;

public class mainCtl extends AbsFrameTest{
public void showAdminDialog(){
	new AdminDialogCtl(this, true).setVisible(true);
	
}
}
