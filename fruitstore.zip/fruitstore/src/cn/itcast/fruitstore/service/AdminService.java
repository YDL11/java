package cn.itcast.fruitstore.service;

import java.util.ArrayList;

import cn.itcast.fruitstore.dao.*;
import cn.itcast.fruitstore.domain.FruiteItem;

public class AdminService {
private AdminDao adminDao=new AdminDao();
public ArrayList<FruiteItem>queryFruiteItem() {
	ArrayList<FruiteItem>data=adminDao.queryAllData();
	return data;
}
public boolean addFruiteItem(String number,String name,String jiage,String unit){
	ArrayList<FruiteItem>data=queryFruiteItem();
    for(int i=0;i<data.size();i++){
    	FruiteItem frt=data.get(i);
    	if(number.equals(frt.getNumber())){
    		return false;
    	}
    }//���û���ظ���Ž����ݷ�װΪFruiteItem����
    FruiteItem thisFruiteItem=new FruiteItem(number,name,
    		jiage,unit);
    adminDao.addFruiteItem(thisFruiteItem);
	return true;
}
public boolean updateFruiteItem(String number,String name,String jiage,String unit){
	//����DAO�µĻ�ȡ�������ݷ�����ȡ��������
	ArrayList<FruiteItem>data=queryFruiteItem();
	//ʹ������ı�ź��������ݶԱ�
	for(int i=0;i<data.size();i++){
		FruiteItem frt=data.get(i);
		if(number.equals(frt.getNumber())){
			adminDao.deleFruiteItem(number);
			FruiteItem thisFruiteItem=new FruiteItem(number,name,
		    		jiage,unit);
			adminDao.addFruiteItem(thisFruiteItem);
			return true;
		}
	}
	return false;
}
public boolean deleFruiteItem(String deleNumber){
	ArrayList<FruiteItem>data=queryFruiteItem();
	for(int i=0;i<data.size();i++){
		FruiteItem frt=data.get(i);
		if(deleNumber.equals(frt.getNumber())){
			//equals()���ж�ǰ�������Ƿ���ͬ
			adminDao.deleFruiteItem(deleNumber);
			return true;
		}
}
	return false;
}
}
