package cn.itcast.fruitstore.app;
import cn.itcast.fruitstore.ctl.*;
import cn.itcast.fruitstore.view.*;
public class MainApp {
public static void main(String[] args) {
	new mainCtl().setVisible(true);
}
}
