package cn.itcast.fruitstore.dao;

import java.sql.DatabaseMetaData;
import java.util.ArrayList;

import cn.itcast.fruitstore.domain.FruiteItem;
import cn.itcast.fruitstore.domain.database;

public class AdminDao {
public ArrayList<FruiteItem> queryAllData(){
	return database.data;
}
//��������
public void addFruiteItem(FruiteItem fuiteItem){
	database.data.add(fuiteItem);
}
//ɾ������
public void deleFruiteItem(String delenumber){
	for(int i=0;i<database.data.size();i++){
		FruiteItem thisFruiteItem=database.data.get(i);
		if(thisFruiteItem.getNumber().equals(delenumber)){
			database.data.remove(i);
		}
	}
}
}
