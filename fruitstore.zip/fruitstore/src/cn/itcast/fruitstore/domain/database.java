package cn.itcast.fruitstore.domain;

import java.util.ArrayList;

public class database {
public static ArrayList<FruiteItem>data=new ArrayList<FruiteItem>();
static {
	data.add(new FruiteItem ("Ѧ֮ǫ","��","1.72","60"));
}
}
