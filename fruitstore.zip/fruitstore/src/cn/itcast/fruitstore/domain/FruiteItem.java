package cn.itcast.fruitstore.domain;

public class FruiteItem {
private String number;
private String name;
private String jiage;
private String nuit;
public FruiteItem(){
	
}
public FruiteItem(String number,String name,String jiage,String nuit){
	super();
	this.number=number;
	this.name=name;
	this.jiage=jiage;
	this.nuit=nuit;
}
public String getNumber() {
	return number;
}
public void setNumber(String number) {
	this.number = number;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getjiage() {
	return jiage;
}
public void setJiage(String jiage) {
	this.jiage = jiage;
}
public String getNuit() {
	return nuit;
}
public void setNuit(String nuit) {
	this.nuit = nuit;
}

}
